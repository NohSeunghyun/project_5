package dao;

public class DonationDAO {

}
