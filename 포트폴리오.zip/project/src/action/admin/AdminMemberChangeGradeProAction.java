package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.admin.AdminMemberChangeGradeService;
import vo.ActionForward;

public class AdminMemberChangeGradeProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String admin_id = request.getParameter("admin_id");
		String id = request.getParameter("member_id");
		String changeGrade = request.getParameter("changeGrade");
		
		AdminMemberChangeGradeService adminMemberChangeGradeService = new AdminMemberChangeGradeService();
		boolean isAdminMemberChangeGradeSuccess = adminMemberChangeGradeService.isAdminMemberChangeGrade(id, changeGrade);
		
		if (!isAdminMemberChangeGradeSuccess) {
			out.println("<script>");
			out.println("alert('비밀번호 변경에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			if (admin_id.equalsIgnoreCase(id)) {
				forward = new ActionForward("admin_MeChangeGradeSuccess.page", false);
			}else {
				forward = new ActionForward("memberChangeGradeSuccess.page", false);
			}
		}
		return forward;
	}

}
