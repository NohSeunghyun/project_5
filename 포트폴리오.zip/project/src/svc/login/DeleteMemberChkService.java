package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class DeleteMemberChkService {

	//회원탈퇴 전 회원구분 Service
	public String isDeleteMemberCategory(String id) {
		String isDeleteMemberCategory = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			isDeleteMemberCategory = loginDAO.isDeleteMemberCategory(id);
		} catch (Exception e) {
			System.out.println("isDeleteMemberCategoryService에러" + e);
		} finally {
			close(con);
		}
		return isDeleteMemberCategory;
	}

}
