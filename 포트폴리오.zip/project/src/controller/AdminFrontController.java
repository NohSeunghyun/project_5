package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import action.admin.AllMemberPersonalInformationProAction;
import action.admin.AdminChangeGradeAdminGradeChkProAction;
import action.admin.AdminChangePwAdminGradeChkProAction;
import action.admin.AdminDeleteProAction;
import action.admin.AdminMemberChangeGradeProAction;
import action.admin.AdminMemberChangePwProAction;
import action.admin.AdminMemberInfoProAction;
import action.admin.ComgrpMemberDeleteProAction;
import action.admin.ComgrpMemberInfoProAction;
import action.admin.JoinMemberShip_adminChkGradeProAction;
import action.admin.JoinMemberShip_adminProAction;
import action.admin.MemberChangeGradeAdminGradeChkProAction;
import action.admin.UpdateComgrpMemberProAction;
import action.admin.UpdateNormalMemberProAction;
import action.admin.MemberChangeGradeProAction;
import action.admin.MemberChangePwAdminGradeChkProAction;
import action.admin.MemberChangePwProAction;
import action.admin.NormalMemberDeleteProAction;
import action.admin.NormalMemberInfoProAction;
import action.admin.UpdateAdminMemberProAction;
import vo.ActionForward;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("*.admin")
public class AdminFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}
	
	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		
		if (command.equals("/allMemberPersonalInformation.admin")) {//관리자 모든 회원 정보조회 처리
			action = new AllMemberPersonalInformationProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/memberChangePwAdminGradeChk.admin")) {//관리자 회원 비밀번호 변경 전 관리자 등급 확인 처리
			action = new MemberChangePwAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/memberChangePw.admin")) {//관리자 회원 비밀번호 변경 처리
			action = new MemberChangePwProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/memberChangeGradeAdminGradeChk.admin")) {//관리자 회원 등급 변경 전 관리자 등급 확인 처리
			action = new MemberChangeGradeAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/memberChangeGrade.admin")) {//관리자 회원 등급 변경 처리
			action = new MemberChangeGradeProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/normalMemberInfo.admin")) {//관리자 일반회원정보 수정 전 정보조회 처리
			action = new NormalMemberInfoProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/updateNormalMember.admin")) {//관리자 일반회원정보 수정 처리
			action = new UpdateNormalMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/normalMemberDelete.admin")) {//관리자 일반회원 삭제 처리
			action = new NormalMemberDeleteProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/comgrpMemberInfo.admin")) {//관리자 기업/단체회원정보 수정 전 정보조회 처리
			action = new ComgrpMemberInfoProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/updateComgrpMember.admin")) {//관리자 기업/단체회원정보 수정 처리
			action = new UpdateComgrpMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/comgrpMemberDelete.admin")) {//관리자 기업/단체회원 삭제 처리
			action = new ComgrpMemberDeleteProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminChangePwAdminGradeChk.admin")) {//관리자 비밀번호 변경 전 관리자 등급 확인 처리
			action = new AdminChangePwAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminMemberChangePw.admin")) {//관리자 비밀번호 변경 처리
			action = new AdminMemberChangePwProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminChangeGradeAdminGradeChk.admin")) {//관리자 등급 변경 전 관리자 등급 확인 처리
			action = new AdminChangeGradeAdminGradeChkProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminMemberChangeGrade.admin")) {//관리자 등급 변경 처리
			action = new AdminMemberChangeGradeProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminMemberInfo.admin")) {//관리자 정보 수정 전 정보조회 처리
			action = new AdminMemberInfoProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/updateAdminMember.admin")) {//관리자 정보 수정 처리
			action = new UpdateAdminMemberProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/adminDelete.admin")) {//관리자 탈퇴 처리
			action = new AdminDeleteProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/joinMemberShip_adminChkGrade.admin")) {//관리자 추가 전 등급확인 처리
			action = new JoinMemberShip_adminChkGradeProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (command.equals("/joinMemberShip_admin.admin")) {//관리자 추가 처리
			action = new JoinMemberShip_adminProAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/******************************포워딩******************************/
		
		if(forward != null) {
			if(forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
			request.getRequestDispatcher(forward.getPath()).forward(request, response);
			}
		}
	}
}


