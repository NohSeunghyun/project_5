package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;
import vo.campaign.CampaignListBean;

public class CampaignListService {

	//모든 캠페인 조회 Service
	public ArrayList<CampaignBean> getCampaign() {
		ArrayList<CampaignBean> campaignList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignList = campaignDAO.getCampaign();
		} catch (Exception e) {
			System.out.println("getCampaignService 에러" + e);
		} finally {
			close(con);
		}
		return campaignList;
	}

	//캠페인 지원 단체 목록 조회 Service
	public ArrayList<CampaignListBean> getCampaignDetailList(int campaign_no) {
		ArrayList<CampaignListBean> campaignDetailList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignDetailList = campaignDAO.getCampaignDetailList(campaign_no);
		} catch (Exception e) {
			System.out.println("getCampaignDetailListService 에러" + e);
		} finally {
			close(con);
		}
		return campaignDetailList;
	}

}
