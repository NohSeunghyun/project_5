package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AdminGradeChkService;
import vo.ActionForward;

public class MemberChangePwAdminGradeChkProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String admin_id = request.getParameter("admin_id");
		String id = request.getParameter("member_id");
		String name = request.getParameter("member_name");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (admin_grade.equalsIgnoreCase("C")) {
			out.println("<script>");
			out.println("alert('변경할 권한이 없습니다.\\nA등급, B등급만 변경가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			request.setAttribute("member_id", id);
			request.setAttribute("member_name", name);
			
			forward = new ActionForward("memberChangePwForm.page", false);
		}
		return forward;
	}

}
