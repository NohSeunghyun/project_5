package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.JoinMemberShip_adminService;
import vo.ActionForward;
import vo.login.AdminMemberBean;

public class JoinMemberShip_adminProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		AdminMemberBean adminMember = new AdminMemberBean();
		
		adminMember.setAdmin_id(request.getParameter("admin_id"));
		adminMember.setAdmin_pw(request.getParameter("admin_pw"));
		adminMember.setAdmin_name(request.getParameter("admin_name"));
		adminMember.setAdmin_phone(request.getParameter("admin_phone1")+"-"+request.getParameter("admin_phone2")+"-"+request.getParameter("admin_phone3"));
		
		JoinMemberShip_adminService joinMemberShip_adminService = new JoinMemberShip_adminService();
		boolean isJoinMemberShipSuccess = joinMemberShip_adminService.joinMemberShip(adminMember);
		
		if (!isJoinMemberShipSuccess) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('회원가입에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("joinMemberShip_adminSuccess.page", false);
		}
		return forward;
	}

}
