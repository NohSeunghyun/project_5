package vo.campaign;

public class CampaignBean {
	private int campaign_no;
	private String campaign_name;
	private String campaign_content;
	private String campaign_all_fund_raised;
	private String campaign_file;
	
	public int getCampaign_no() {
		return campaign_no;
	}
	public void setCampaign_no(int campaign_no) {
		this.campaign_no = campaign_no;
	}
	public String getCampaign_name() {
		return campaign_name;
	}
	public void setCampaign_name(String campaign_name) {
		this.campaign_name = campaign_name;
	}
	public String getCampaign_content() {
		return campaign_content;
	}
	public void setCampaign_content(String campaign_content) {
		this.campaign_content = campaign_content;
	}
	public String getCampaign_all_fund_raised() {
		return campaign_all_fund_raised;
	}
	public void setCampaign_all_fund_raised(String campaign_all_fund_raised) {
		this.campaign_all_fund_raised = campaign_all_fund_raised;
	}
	public String getCampaign_file() {
		return campaign_file;
	}
	public void setCampaign_file(String campaign_file) {
		this.campaign_file = campaign_file;
	}
	
}