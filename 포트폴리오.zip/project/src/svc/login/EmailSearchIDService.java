package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class EmailSearchIDService {
	
	//이메일주소로 아이디찾기 Service
	public String searchID(String name, String email) throws Exception {
		String searchID = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			searchID = loginDAO.emailSearchID(name, email);
		} catch (Exception e) {
			System.out.println("emailSearchIDService에러" + e);
		} finally {
			close(con);
		}
		return searchID;
	}
}
